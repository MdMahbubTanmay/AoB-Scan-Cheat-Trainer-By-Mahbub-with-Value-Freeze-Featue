using Memory;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace MyCheat
{
    public partial class Form1 : Form
    {
        Mem mem = new Mem();
        static string ProcessName = "Ld9BoxHeadless"; // Name of the emulator process



        List<long> Antenna_address = new List<long>(); //Add A list for address here


        public Form1()
        {
            InitializeComponent();

        }

        private async void button1_Click(object sender, EventArgs e)
        {
            // Try to find emulator process
            Process? emulator = Process.GetProcessesByName(ProcessName).FirstOrDefault();
            if (emulator == null)
            {
                MessageBox.Show("Emulator (Ld9BoxHeadless) not found.");
                return;
            }

            if (!mem.OpenProcess(emulator.Id))
            {
                MessageBox.Show("Failed to open emulator process.");
                return;
            }

            string aobPattern = "6B 70 D8 BF"; // Replace with your AOB pattern

            try
            {
                var scanResult = await mem.AoBScan(aobPattern, true, true);
                Antenna_address = scanResult.ToList();

                if (Antenna_address.Count == 0)
                {
                    MessageBox.Show("No addresses found.");
                }
                else
                {
                    MessageBox.Show($"{Antenna_address.Count} address(es) found and stored.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("AOB Scan Error: " + ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Antenna_address.Count == 0)
            {
                MessageBox.Show("No addresses stored. Please scan first.");
                return;
            }

            foreach (var address in Antenna_address)
            {
                bool success = mem.WriteMemory("0x" + address.ToString("X"), "float", "9999999"); // You can change type/value here
                if (!success)
                    MessageBox.Show($"Failed to write to address 0x{address:X}");
            }

            MessageBox.Show("All addresses updated.");
        }

        private void button3_Click(object sender, EventArgs e)
        {

            if (Antenna_address.Count == 0)
            {
                MessageBox.Show("No addresses stored. Please scan first.");
                return;

            }


            else
            {

                //This is the timer which will help us freezeing values.
                System.Windows.Forms.Timer

                AntennaFreezer = new System.Windows.Forms.Timer();
                AntennaFreezer.Interval = 500; // 0.5 seconds
                AntennaFreezer.Tick += (s, ev) =>
                {



                    foreach (var address in Antenna_address)
                    {
                        mem.WriteMemory("0x" + address.ToString("X"), "float", "9999999"); // You can change type/value here
                        
                    }



                 };

              AntennaFreezer.Start();  
            }
          

        }
    }
}
